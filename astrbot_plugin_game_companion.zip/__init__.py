"""AstrBot Game Companion plugin."""
